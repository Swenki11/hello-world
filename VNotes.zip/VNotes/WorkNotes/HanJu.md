# <center>韩剧TV<center>


### 运用技术 + 实现功能和取得的结果 + 遇到的问题 +解决方法

#### 三星、华为、OPPO等厂商折叠屏适配。

两种适配模式：
1. 三星使用android回调比较方便
2. 华为OPPO使用平板-手机状态/平行视界两种方式。


1. 常规适配：华为、oppo。
    - 设备区分为平板和普通手机两种状态，在切换设备状态时会触发onConfigurationChanged 回调。具体需要的UI展示效果根据当前的页面进行确定。
    - HuaWeiFoldDeviceUtil.kt：DEVICE_MODEL_LIST 添加相关机型。
2. 平行视界：华为、oppo。 
    - easygo.json 配置见文档。  
    https://developer.huawei.com/consumer/cn/doc/development/HMSCore-Guides/configuration-file-add-0000001222792620
    - HuaWeiFoldDeviceUtil.kt：isParallelHorizon 控制不使用常规适配。
3. androidx.window:window库：Google推荐的折叠屏适配方式、目前三星在使用。  
    - 通过注册监听去获取当前的设备状态，不需要像常规适配去判断是平板还是手机，并且能对折叠中状态(半折)给出回调。
    - LayoutStateChangeCallback.kt：注册监听类。      
    <br/>

    > 这个库一直在更迭，升级的时候需要根据文档进行调整。  
    

#### 讨论区问题
使用ViewModel同步数据
使用内存缓存最近的讨论区数据解决断网进入的问题 （这里需要加锁，避免suspend函数多线程访问）
1. ViewModle 同步同一Activity的数据，对帖子加载、同步、删除都在这里面做。
2. ViewRepo单例，缓存讨论区数据（设置最大讨论区数量）获取以及更新需要加锁  


#### 消息系统

这部分主要是消息分类比较繁琐 需要处理好消息的对照关系 技术上难点不强

#### 帖子生成长图
技术：协程+canvas view转bitmap bitmap的拉升裁剪比例
功能：动态生成帖子分享图（固定拼接内容 + 图片 + 文字）
难点：多bitmap比较吃缓存，特别是图片较多的时候,并且要保证图片（可能九张）是顺序加载
解决：用一个hasMap去存顺序（后面想想其实用协程suspend更好）因为是异步代码同步

&emsp;需要拼接的内容：帖子内容(不包括图片、投票)、帖子投票、头部标识、底部二维码、内容过长时折叠标识、帖子图片(n张)/视频封面。
&emsp;具体步骤：
    - 确定图片宽度(手机屏幕宽度)、确定图片最小高度、确定图片最大高度。
    - 获取固定内容缩放后的图片：帖子内容(不包括图片、投票)、帖子投票、头部标识、底部二维码和内容过长时折叠标识。
    - 获取动态内容缩放后的图片：帖子图片(n张)/视频封面。  
        > 这里用图片最大宽度约束了最多需要的图片张数，不过度加载图片。
    - 所有可能需要拼接资源加载完成后，根据所有图片高度计算折叠的位置，并把真正需要拼接的的图片根据添加位置依次排序。    
        ```kotlin
        private val POSITION_NULL = 0     //不裁剪
        private val POSITION_CONTENT = 1  //裁剪内容
        private val POSITION_PHOTO_AND_VIDEO = 2    //裁剪图片, 视频封面
        private val POSITION_VOTE = 3     //裁剪投票图片
        ```
    - 根据上一步中剩下的高度、图片最小高和图片最大高度来确定图片真实高度。
    - 根据确定的图片宽度与高度，生成空bitmap。然后根据不同的裁剪位置，对应的绘制出分享图，并显示在界面。  
    
    > 可改善的地方：这里加载图片的方式有些浪费性能，AI头像里面的PhotoDownloadUtil.kt处理更好。
    
<br/>  

#### 注销流程
提-> 原因->结果反馈
技术：开始使用的是协程+dialogfragment（类似于登陆 ）发现直接用
结果：成功实现了注销功能
问题：全局的rescode处理
方法：在基类appCompat和fragmentactivity 注册一个全局的livedate 
请求接口时处理rescode 根据逻辑选择是否postvalue 并用栈顶的activity去处理
  



#### 鸿蒙卡片项目

技术：okhttp+retrofit 
结果：实现了服务应用的内容 获取了推荐位
问题：1.部分文档内容不清晰，调试需要联调。2.没有完善的三方库 特别是图片3.生命周期
4. 一个项目的启动 技术选型 项目构建  开发设计 编译打包签名上架一整个流程。
方法：图片库自己写了一个类似glide的缓存，生命周期采用了类似android service去保活
 需要注意的地方：系统的onCreateForm回调后相当于走完了生命周期，需要启动类似Android中service的组件去加载并显示卡片图片。
 

#### Android 11 存储适配相关
技术：handler IO线程处理文件 UI线程显示当前的状态
结果：成功将旧版存储结构转变为android分区存储
问题：1.升级带来的兼容问题 2.文件转移时的场景考虑问题（上传，下载，位置，权限等）
方法：针对不同版本进行对应的处理
整个过程大致分为以下几个步骤：
  1. androidmanifest文件进行相关声明：具体见林秋文档。
  2. 转移旧文件 -> 新文件。
  3. 对正在上传/下载的文件进行处理。
  4. 修改对应数据库的路径信息(存相对路径的一般不需要处理)。  
    
图片保存到公共相册：首先需要申请权限(读的时候在高Android版本有时候不需要，但是建议读公共相册图片的时候也直接申请权限)。
1. Android 10 及以上采用 MediaStore API 读取。
2. Android 10 以下采用 File 文件流的形式读取。      

<br/>
<br/>




### 运用技术 + 实现功能和取得的结果 + 遇到的问题 +解决方法


分享SDK接入


