# <center>工作交接<center>


### 韩剧

#### 折叠屏需求
1. 常规适配：华为、oppo。
    - 设备区分为平板和普通手机两种状态，在切换设备状态时会触发onConfigurationChanged 回调。具体需要的UI展示效果根据当前的页面进行确定。
    - HuaWeiFoldDeviceUtil.kt：DEVICE_MODEL_LIST 添加相关机型
2. 平行视界：华为、oppo。 
    - easygo.json 配置见文档。  
    https://developer.huawei.com/consumer/cn/doc/development/HMSCore-Guides/configuration-file-add-0000001222792620
    - HuaWeiFoldDeviceUtil.kt：isParallelHorizon 控制不使用常规适配
3. androidx.window:window库：Google推荐的折叠屏方式、三星使用。  
    - 通过注册监听去获取当前的设备状态，不需要像常规适配去判断是平板还是手机，并且可能对折叠中状态(半折)给出回调。
    - LayoutStateChangeCallback.kt：注册监听类。     
    > 这个库一直在更迭，升级的时候需要根据文档进行调整。  
      
  
<br/>
<br/>

#### 鸿蒙卡片项目

1. 开发工具：DevEco-Studio。
2. 开发文档：https://developer.huawei.com/consumer/cn/develop-novice-guide/
3. 开发细节：  
    - 配置文件：config.json。
    - 接口：与ios小组件使用同样的接口，包括追剧接口和推荐接口。
    - 网络请求：retrofit + okhttp。
    - 数据库：采用开发文档给出的基础数据库。帮助类：Preferences、CardSeriesTableHelper。
    - 图片加载：    
        * 具体页面(点击卡片后打开的页面)的加载：Glide。
        * 卡片图片的加载：网络请求数据后，输入输出写入。一开始三方库都还没提供完整功能，只能通过这种方式下载到本地然后展示到卡片上面。  
    - 需要注意的地方：系统的onCreateForm回调后相当于走完了生命周期，需要启动类似Android中service的组件去加载并显示卡片图片。
      
<br/>
<br/>

#### Android 11 存储适配相关
&emsp;这部分是承接林秋的部分工作继续进行的，几个用到的目录路径以及对应权限的关系可见林秋交接文档。整个过程大致分为以下几个步骤：
  1. androidmanifest文件进行相关声明：具体见林秋文档。
  2. 转移旧文件 -> 新文件。
  3. 对正在上传/下载的文件进行处理。
  4. 修改对应数据库的路径信息(存相对路径的一般不需要处理)。  
    
图片保存到公共相册：首先需要申请权限(读的时候在高Android版本有时候不需要，但是建议读公共相册图片的时候也直接申请权限)。
1. Android 10 及以上采用 MediaStore API 读取。
2. Android 10 以下采用 File 文件流的形式读取。      
>  具体看AITouXiang项目中的PhotoDownloadUtil.kt文件。

<br/>
<br/>

#### 合规整改相关
1. 通过反射去屏蔽掉敏感API的调用，例子：HookClipBoardForAliyunFeedBack.java。
2. 通过 VirtualXposed 去检测手机是否调用相关敏感API。使用方法见：https://git.code.tencent.com/bbc_android/trial_projects/tree/master/HookDemo  
> 到目前为止，上面两个都用不到了，基本上升级有问题的SDK，去除掉本地代码对敏感API的调用即可。

<br/>
<br/>

#### 其他
1. **消息系统：**  
    - MessageContentType：消息类型。
    - PreviewMessageAdapter.kt：展示预览消息。
    - ConversationMessageAdapter.kt：展示对话消息。
    > 类型比较多，有的消息需要拼接多个带点击事件的文字，要多次使用SpannableString。没有特别困难复杂的地方，增加一个类型的时候，找到一个已有类型进行比较就可以。  
 
<br/>

2. **剧集简介图集：**  
    - SeriesDetailIntroFragment.java：简介弹框横向展示图片。
    - SeriesGalleryFragment.kt：网格弹窗展示图盘。
    - GalleryBigImageActivity: 查看大图。
    - SeriesGalleryViewModel.kt: 同步数据，上面三个查看图片位置都需要分页加载，且前两者需要同步分页后的图片数据。  
    
<br/>

3. 用户关注迭代：  
&emsp;后续迭代应该比较简单，说明一下几个样式。
    - 关注/粉丝——FollowOrFansUserAdapter.kt)
    - 新增粉丝——NewFansAdapter.kt
    - 推荐用户——RecommendUserAdapter.kt  

<br/>

4. **帖子生成长图**  
&emsp;需要拼接的内容：帖子内容(不包括图片、投票)、帖子投票、头部标识、底部二维码、内容过长时折叠标识、帖子图片(n张)/视频封面。
&emsp;具体步骤：
    - 确定图片宽度(手机屏幕宽度)、确定图片最小高度、确定图片最大高度。
    - 获取固定内容缩放后的图片：帖子内容(不包括图片、投票)、帖子投票、头部标识、底部二维码和内容过长时折叠标识。
    - 获取动态内容缩放后的图片：帖子图片(n张)/视频封面。  
        > 这里用图片最大宽度约束了最多需要的图片张数，不过度加载图片。
    - 所有可能需要拼接资源加载完成后，根据所有图片高度计算折叠的位置，并把真正需要拼接的的图片根据添加位置依次排序。    
        ```kotlin
        private val POSITION_NULL = 0     //不裁剪
        private val POSITION_CONTENT = 1  //裁剪内容
        private val POSITION_PHOTO_AND_VIDEO = 2    //裁剪图片, 视频封面
        private val POSITION_VOTE = 3     //裁剪投票图片
        ```
    - 根据上一步中剩下的高度、图片最小高和图片最大高度来确定图片真实高度。
    - 根据确定的图片宽度与高度，生成空bitmap。然后根据不同的裁剪位置，对应的绘制出分享图，并显示在界面。  
    
    > 可改善的地方：这里加载图片的方式有些浪费性能，AI头像里面的PhotoDownloadUtil.kt处理更好。
    
<br/>  

5. **注销流程**    
    * 注销提示页 -- CancelAccountNotifyActivity.kt
    * 注销原因页 -- CancelAccountReasonActivity.kt
    * 注销结果页 -- CancelAccountFeedBackActivity
    * 其他设备注销后通过全局Rescode下线 -- CancelAccountOtherDevicesFragment.kt
    * 登录时在审核期提示 -- CancelAccountLoginNotifyFragment.kt

<br/>  

6. **缓存控制与缓存上限**  
    - 首页请求缓存控制接口。最低间隔：6h。
    - 成功后更新所有缓存的项目信息。  
        ```kotlin
        // 缓存类型
        const val TYPE_ALWAYS = 1
        const val TYPE_PERIOD = 2
        const val TYPE_REJECT = 3
        ```
        * Any -> TYPE_REJECT 不区分是否完成，将对应集pid添加到删除list。
        * Any -> TYPE_ALWAYS 不区分是否完成，只更新数据库control信息。
        * Any -> TYPE_PERIOD     
            * 未完成：只更新数据库control信息。
            * 已完成：TYPE_ALWAY/TYPE_PERIODS -> TYPE_PERIOD 将到期的集pid添加到list，更新缓存时间，更新control信息。  
     - 将需要list内对应集删除。   
    > 这里每一个缓存项都有cacheControl信息。

<br/>  
<br/>  


### HiTV 

#### HiTV

#### 预告相关
1. 分类：预告剧(包含剧预告)，正式剧(包含集预告/不包含集预告)。
2. 预告不保存播放记录、不支持缓存。
3. 请求详情时删除所有预告再更新数据库，因为每次要更新数据库的预告信息。
4. 历史记录(VideoPlayHistoryView.kt)增加eid，根据eid来确定确定播放位置，不再采用seriesNo，因为预告可能导致seriesNo混乱。
5. 综艺/电影/剧集 有不同的排序方式

<br/>  

#### 清晰度与激励广告
1. 默认清晰度：集清晰度(SvrPlayItemSource.preferQuality，用于在线播放的默认选中)和剧集清晰度(SeriesView.preferQuality，用于缓存时的默认选中)。
2. 激励广告  
    - 剧集解析接口获取SvrVipAccess，保存到临时存放位置ResolveDataHelper。
    - 在LevelControl对对应level的清晰度进行试看样式设置。这部分代码比较难以理解。   
         ``` kotlin
         fun setView(position: Int) {
                val videoBean = mLevelList?.get(position)

                //会员清晰度且已开通该会员
                //这种情况下用户有了使用该清晰度的权限，所以不会出现试看的情况，展示示例：
                /**
                 * 1080 (选中时有无vip角标/未选中时有，点击直接切换清晰度，不跳转vip购买页面)
                 * 720
                 * 360
                 */
                if (LoginInfo.isVipLevel(videoBean?.vipType) &&
                    LoginInfo.isOwnVipLevel(videoBean?.vipType)) {
                    setNormalType(videoBean, position)
                    return
                }

                // is trial type and not chosen
                // 这种情况是服务器给了试看，展示示例：
                /**
                 * 【1080】【】表示试看未选中
                 * 720
                 * 360
                 */
                val vipAccess = JsonUtil.safeParseObject(ResolveDataHelper.getTempVipAccess(), SvrVipAccess::class.java)
                if (LoginInfo.isTrialLevel(vipAccess?.accessType, vipAccess?.scene, videoBean?.level)) {
                    setTrialType(videoBean, position)
                    return
                }

                // 其他情况都是普通展示，展示示例：
                /**
                 * 1080 (选中时有无vip角标/未选中时有，点击跳转vip购买)
                 * 720
                 * 360
                 */
                setNormalType(videoBean, position)
            }
         ```
    - 用户点击试看标识的清晰度后通过VideoBridge的onChangeVideo回调开始真正的广告请求逻辑(RewardCoroutines.kt)：获取激励广告配置 -> 激励广告播放(广告SDK调用，结束后的回调看具体代码) -> 获取激励完成，激励广告上报，获得token，并将token存到videoInfo的extra信息中，Key为VideoExtraKey.TRIAL_TOKEN。
    - 自动切换选集，根据token获取到此次清晰度权益，切换成功，流程结束。  
    > 该广告无法中途退出。

<br/>  

#### 投放命中功能
1. 整体流程：  
    - 用户在投放平台点击广告，并下载app。Singular会为设备保存我方配置的广告信息(sid)。
    - 用户打开app后，Singular初始化并获取到该设备点击的广告对应的信息(sid)。
    - 根据对应信息(sid)向自身服务器获取需要展示的UI信息(SeriesView)，并展示在界面上。
2. 实现细节：  
    - 在用户点击广告下载打开app后，Singular<mark>只</mark>会在第一次初始去获取对应的广告信息(sid)，后续打开app都不会去获取，所以采用一个key去记录是不是第一次初始化Singular。
    - Singular获取广告信息与首页接口获取信息无法获悉两者获取信息的相对时机。（1）Singualr先获取到：在首页数据准备好后进行添加。（2）Singualr先后获取到：通过EventBus去通知首页展示。
    - 其他：只在首页第一个Fragment展示，其他不展示；下拉刷新首页数据后，保持广告信息的展示。


<br/>  

#### 播放器逻辑与UI
1. 拖动seekbar时跟随显示视频进度:    
&emsp; 将view放在BottomController里面，在拖动进度条原点的时候，计算出view的起始位置并调用setX进行设置。
2. 快进快退10秒功能：    
    - 显示场景：SeriesStateController显示/View单独显示、点击View/双击空白区域、全屏/竖屏。
        - SeriesStateController显示/View单独显示：前者是和播放暂停音量等控件同步展示、后者是只有前进和后退两个控件。SeriesStateController里的控制本身比较复杂，所以为了单独显示快进快退，重新再添加了一个SeriesDoubleClickBackwardOrForwardController，SeriesDoubleClickBackwardOrForwardController中的控件位置与SeriesStateController中的位置一致。
        - 点击View/双击空白区域：SeriesStateController中的快进快退控件支持双击空白区域也支持view的点击事件，也可以响应两者的混合点击。比如：点击view后在进行动画，然后点击动画就会再快进/快退一次，再双击空白区域又会快进/快退一次。SeriesDoubleClickBackwardOrForwardController只支持双击空白区域，点击view不会增加快进/快退次数，点击两次view会触发一次快进/快退，但是是属于双击事件导致的快进/快退，view本身不消费点击事件。
        - 全屏/竖屏：使用TwinDoubleClickBackwardOrForwardController和TwinStateController进行全屏和竖屏的样式切换。  
    - 触发时机代码：GestureVideoView.kt，处理双击事件与单机事件的冲突。   
        -  奇数次点击：触发onTap(), 如果之前有双击事件并且与双击事件的时间间隔在ViewConfiguration.getDoubleTapTimeout()内，不处理。比如连续点击三次，只触发一次双击时间，最后一次点击不消费。其他情况：在经过ViewConfiguration.getDoubleTapTimeout()时间之后，去触发tapEvent()。
        * 偶数次点击：与第一次间隔在ViewConfiguration.getDoubleTapTimeout()时间内，会触发一次onDoubleTap()，这时候要remove掉第一次点击时的tapEvent()，总体只触发一次双击事件，记录mDoubleClickTime。与第一次间隔超过ViewConfiguration.getDoubleTapTimeout()，这时候一定完成了第一次点击时的tapEvent()，去延时一个新的tapEvent()。  
         
    ```java
    
        /**
        * 点击示例：连续点击表示两次间隔在ViewConfiguration.getDoubleTapTimeout()内
        * 点击一次 -> tapEvent()
        * 连续两次 -> onDoubleTap()
        * 点击两次 -> 两次tapEvent()
        * 连续三次 -> onDoubleTap() 最后一次点击不响应。
        * 连续两次 点击一次 -> onDoubleTap() tapEvent() 最后一次点击响应。
        * 依此类推 ......
        */
           
        @Override
        public void onTap(MotionEvent event) {
            //点击一次
            if (System.currentTimeMillis() - mDoubleClickTime < ViewConfiguration.getDoubleTapTimeout()) {
                return;
            }
            mDoubleClickTime = -1L;
            mGestureHandler.removeCallbacksAndMessages(null);
            mGestureHandler.postDelayed(() -> tapEvent(event), ViewConfiguration.getDoubleTapTimeout());
        }
    

        @Override
        public void onDoubleTap(MotionEvent event) {
            //点击两次

            mDoubleClickTime = System.currentTimeMillis();
            mGestureHandler.removeCallbacksAndMessages(null);

            boolean isForward = event.getX() > getWidth() / 2f;
            if (mStateController != null && mStateController.isShowCenterView()) {
                mStateController.performBackwardOrForward(isForward);
                return;
            }
            mDoubleClickBackwardOrForwardSController.show();
            mDoubleClickBackwardOrForwardSController.performBackwardOrForward(isForward);
        }
    ```


<br/>  
<br/>  

### AI头像

#### 首页banner
#####  三方库：旋转木马效果 https://github.com/Azoft/CarouselLayoutManager
&emsp;CarouselLayoutManager实现RecycleView中Item绘制顺序的重排序。默认manager的绘制顺序是按照item的位置进行顺序绘制。CarouselLayoutManager中将两侧的Item先绘制，然后将当前选中的Item最后绘制。

##### 本地控制：CarouselRecycleView
&emsp;三方库未实现自动轮播功能，不能控制滑动的速度。本地CarouselRecycleView实现上述功能。效果：自动轮播且能设置轮播时间，能设定翻页滑动距离与Item宽度的最小比例从而控制滑动效果。
1. 自动轮播：Handler实现。
2. 控制滑动：      
    - 在Android系统中，每次滑动后都会有一个离开时的滑动速度，同时也有一个minFlingVelocity。以RecycleView为例，如果这个离开时速度小于minFlingVelocity，则不会惯性滑动，否则会惯性滑动（比如小距离快速滑动可以滑很远，长距离慢速滑动滑多少控件就移动多少）。    
    - 在 dispatchTouchEvent中，记录点击和离开时的x位置，用以算出本次滑动的距离，记录点击时的选中位置mTouchPosition。
    - 重写fling来控制惯性滑动。通过mAcceptFlingRatio设置最小滑动距离与item宽度的比例。一些场景：  
        - 离开时速度很快，超过minFlingVelocity：  
            1. 未超过最小判定距离：不滑动，回归到原来的位置。
            2. 超过最小判定距离： findTargetSnapPosition()中处理已经滑动到目标位置（滑动距离大，最后离开时速度快）和还在当前位置（滑动距离小，离开速度快）的情况，根据速度方向得到一个目标位置。
        - 离开时速度很慢，未超过minFlingVelocity：不处理，回归到当前（可能滑过了一个item）的位置。
     
```kotlin 
    override fun fling(velocityX: Int, velocityY: Int): Boolean {
        // 让一次滑动只滑动一个item 需要用到记录的 mTouchPosition

        val delX = mOutX - mTouchX
        // 速度与移动方向不一致。多次快速滑动会出现，屏蔽掉。
        if (delX * velocityX > 0) { 
            return false
        }

        // 计算最小翻页滑动距离，取item的mAcceptFlingRatio，小于这个值不翻页
        var minMoveX = -1
        for (i in 0 until (layoutManager?.childCount ?: 0)) {
            val child = layoutManager?.getChildAt(i) ?: continue
            if (child.width > minMoveX) {
                minMoveX = child.width
            }
        }
        minMoveX = (minMoveX * mAcceptFlingRatio).toInt()
        if (abs(delX) < minMoveX || abs(delX) > (Float.MAX_VALUE / 2)) {
            return false
        }
        val localLayoutManager = layoutManager ?: return false

        return ((abs(velocityX) > minFlingVelocity) && snapFromFling(localLayoutManager, velocityX))
    }
    

    private fun findTargetSnapPosition(layoutManager: LayoutManager, velocityX: Int): Int {
        val itemCount = layoutManager.itemCount
        if (itemCount == 0) {
            return NO_POSITION
        }

        val currentPosition = getCurrentPosition()
        if (currentPosition == NO_POSITION || mTouchPosition == NO_POSITION
            || currentPosition != mTouchPosition
        ) {
            // 不处理
            return NO_POSITION
        }

        val forwardDirection: Boolean? = if (layoutManager.canScrollHorizontally()) {
            velocityX > 0
        } else {
           null
        }

        forwardDirection ?: return NO_POSITION

       
        return (if (forwardDirection) mTouchPosition + 1 else (mTouchPosition - 1 + (layoutManager.itemCount)) % (layoutManager.itemCount))
    }
```

<br/>  

#### 大图查看
##### 三方库：https://github.com/davemorrissey/subsampling-scale-image-view
##### 缓存流程：PhotoDownloadUtil
 - 加载图片时通过Glide下载原图到本地，再将资源设置给三方库SubsamplingScaleImageView。这里是原图下载到了Glide的设定的磁盘目录，属于app的私有目录，不需要权限。这里并没有使用Glide去加载到控件，也就不需要用内存去缓存Bitmap。
 - 用户保存图片到本地时，之前加载过的大图已经下载到了Glide设定的磁盘目录，虽然走了下载的代码，其实并没有再真正的去下载，而是直接返回了这个文件路径。下载后保存以Android 10为界限采用不同的导出方式。
 - 用户下载多张时用一个变量count去记录成功的数量，从而判断整体的下载情况。   