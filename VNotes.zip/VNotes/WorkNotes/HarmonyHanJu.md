
# <center>鸿蒙服务项目<center>

Glide + Retrofit + okhttp

问题一：加载上半圆角 解决办法：使用transform
问题二：Ability和AbilitySlice生命周期导致加载失败 

实现功能：图片加载，应用跳转（需原应用配合）/跳转应用市场

结果：于鸿蒙发布时同步上线并获得推荐位，根据合作人员获知点击情况很可观。