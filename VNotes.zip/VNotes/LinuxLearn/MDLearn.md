# MDLearn


# 标题1
## 标题2
### 标题3
#### 标题4
##### 标题5
###### 标题6
####### 标题7

> 这是一段引用 

把大象放进冰箱：
1. 打开冰箱
2. 把大象放进去
3. 关上冰箱     
  
 无序列表 ：-- *
 - 撒打算
 - 撒打算
 * 撒打算大  
   
任务列表：
明天要做的事：-[ ] - [x]
- [x] 吃饭 
- [ ] 睡觉
- [ ] 打豆豆    
  
代码块：
```c
int main() {
    return 0;
}
```


数学公式 :
$E=mc^2$    
$$E=mc^2$$

表格：
| 姓名 | 年龄 | 成绩 |
| :--- | :--: | ---: |
| 张三 |  19  |   71 |
| 李四 |  20  |   89 |

脚注：
一键三连 [^三连]

 [^三连]:点赞投币收藏
  

横线：

---


链接：

[Google](https://www.google.com/ "一个搜索引擎")

[Google][id] [Google][id] [Google][id] [Google][id]

[id]:https://www.google.com/ "一个搜索引擎"

请参考[标题1](#标题1)

URL：
http://www.google.com/

![Google](https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png "google搜索")


![哈哈哈哈](https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png)

![](vx_images/205123716278690.png "google 搜索")


*斜体*

**加粗**

`printf()`

<u>下划线</u>

:smile: 

[emoji表情](https://unicode.org/emoji/charts/full-emoji-list.html)

$\theta=x^2$

H~2~O x^2^

<mark>这是一段高亮文字</mark>


不支持

<iframe src="//player.bilibili.com/player.html?aid=327623069&bvid=BV1JA411h7Gw&cid=171385214&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

