# SSH&传输文件

为了远程链接linux服务器，选择学习一下SSH

## SSH

### ssh连接
* 指令：
```
ssh user@remote -p port
```
* 参数说明：  
user -- 用户名
remote -- 主机名、地址
port -- 端口 可以不写 默认22
### 安装 OpenSSH Server
* 未安装时出现的报错：
```
connect to host remote port 22: Connection refused
```
* 安装指令：
```
sudo apt-get install openssh-server
```

### 公钥验证
优点：不用每次都输入密码，如果主机ip会变的话，就不是很建议。 
* 生成ss钥匙： 
```
ssh-keygen
```
* 远程机器记住公钥：
```
ssh-copy-id user@remote -p port
```
* 配置文件：  ~/.ssh/config 
```
Host my_device_name
    HostName remote
    User user
    Port port
```

## 传输文件

### SFTP
#### sftp连接：
* 指令：
```
sftp -P remote_port remote_user@remote_host
```
* 参数说明：
remote_port -- 端口 可以不写 默认22
remote_user -- 用户名
remote_host -- 主机地址
#### 传输文件
##### 拉取文件
```
get 服务器上文件的目录地址 本地存放的目录地址
```
* 从远程服务器拉取文件到本地：newName不写默认原文件名。
```
get remoteFile [newName]
``` 
* 拉取整个目录：
```
get -r remoteDirectory
```
##### 上传文件
```
put 本地存放的目录地址 服务器上文件的目录地址
```
* 从本地上传文件到服务器：  
```
put localFile
```
* 上传整个目录：如果服务器上不存在这个目录需要首先新建。  
```
put -r folderName
```
### scp
说明：与sftp类似，但是要加上“user@remote”
```
# 把本地的 /path/to/local/file 文件传输到远程的 /path/to/remote/file
scp -P port /path/to/local/file user@remote:/path/to/remote/file
```
---

<mark>todo: 端口转发待学习</mark>

[参考博客](https://zhuanlan.zhihu.com/p/21999778)
[参考博客](https://zhuanlan.zhihu.com/p/339808892)
[参考博客](https://zhuanlan.zhihu.com/p/595641863?utm_id=0)
