### LinuxLearn
Created by Swenk

#### Linux 基础软件的安装 

##### 网络链接的三种模式

1. 桥接模式(张三)
虚拟系统可以和外部系统相互通讯，但是网段相同，容易造成IP冲突。
2.  NAT模式 网络地址转换模式(李四)
虚拟系统可以和外部系统相互通讯(非直接，需要经过母机)，不会造成IP冲突。
3. 主机模式  
独立系统，不和外部发生联系。
![network_mode](vx_images/486515897836216.png)

##### 虚拟机快照
![vm_shortcut](vx_images/588952930951059.png)

##### 虚拟机迁移与删除
  ![vm_delete](vx_images/201885294899463.png)
  
##### 安装vmtools 
/mnt/hgfs 为共享目录
![vmtools](vx_images/323124523586105.png)

#### Linux基本指令

##### linux的目录结构
目录说明
![mulu1](vx_images/57882417132584.png)
![mulu2](vx_images/118702465946928.png)
![mulu3](vx_images/138812675817114.png)
![mulu4](vx_images/269914007911254.png)

##### linux远程登录
mac环境下见笔记：[SSHLearn.md](file:///Users/songwenkui/Library/Mobile%20Documents/com~apple~CloudDocs/VNotes/LinuxLearn/SSHLearn.md)
##### vi vim学习
1. 三种模式
![vi_mode_translate](vx_images/188673402625310.png)
![vi_mode](vx_images/230475706532794.png)

2. 快捷键 可以到网上找更多快捷键的使用 快捷键图
![vi_shortcut](vx_images/542864865559170.png)

##### 关机重启命令、用户登录和注销
![shutdown_reboot](vx_images/445956425951061.png)
![login_logout](vx_images/213857289899465.png)

##### 用户管理

###### 用户相关指令

```
# 添加用户
# -d directory 指定目录 可以不和username同名
useradd -d directory username

# 设置密码
passwd username

# 删除用户 -r(慎重) 代表删除对应家目录
userdel -r username

# 用户信息
id username

# 切换用户 "-" 实际操作中不带也可以 高权限可以直接切换到低权限
su - username

# 查看登录时的用户，切换用户不会改变信息
who am i 

# 用户组
groupadd groupname
groupdel groupname

# 不加 -g 默认创建一个跟用户名相同的组
useradd -g groupname username 

# 用户更换组
usermod -g groupname username 
```

###### 用户相关文件
![user_relative_file](vx_images/292390425586107.png)


#### Linux实用指令
##### 运行级别
* 基本介绍
![run_level](vx_images/327222124132585.png)
* 切换级别实操
```
init [0123456]
```
* 指定允许级别
![set_run_level](vx_images/394282472946929.png)

* 找回root密码（不同系统具体场景不一样，但都是单用户级别更改密码）
1. 登录之前按“e”，找到以 aLinux16” 开头内容所在的行数”，在行的最后面输入：init-/bin/sh（进入单用户模式）。
2. 接着，输入完成后，直接按快捷键：Ctrl+x 进入单用户模式。
3. 接着，在光标闪烁的位置中输入：mount -o remount,rw/(注意：各个单词间有空格），完成后按键盘的回车键 (Enter)。
4. 在新的一行最后面输入：passwd， 完成后按键盘的回车键(Enter）。
5. 接着，在鼠标闪烁的位置中（最后一行中）输入：touch /.autorelabel（注意：touch 与/后面有一个空格），完成后按键盘的回车键(Enter).
6. 继续在光标闪烁的位置中，输入：exec /sbin/init(注意exec 与/后面有一个空格)，完成后按键盘的回车键(Enter）,等待系统自动修改密码(韩顺平提示：这个过程时间可能有点长，耐心等待)，完成后，系统会自动重启，新的密码生效了。

##### 帮助指令
![help_order](vx_images/47263482817115.png)

##### 文件目录指令

###### 基础指令
```
# 显示绝对路径
pwd

# -a -l -al 最常用
ls [选项] [目录或者文件]

# ~ 代表回到自己的家目录
cd [参数]

# 创建目录(默认一级目录) -p 创建多级目录
mkdir [选项] dirname

# 默认删除空目录
rmdir [选项] dirname

# 删除非空目录 (谨慎)
rm -rf dirname

# 创建空文件
touch filename

# 拷贝指令 -r 递归复制整个文件夹 \cp 强制覆盖不提醒
cp [选项] source dest

# 移除指令 -r 递归删除整个文件夹 -f 强制删除不提醒
rm [选项] file/dir

# 移动/重命名 文件/目录
mv oldfile/dir newfile/dir 

# 查看文件内容 -n 显示行号  | more 管道命令
cat [选项] filename
```
###### 其他指令
1. more指令
![order_more](vx_images/127852007911256.png)
2. less指令
![order_less](vx_images/103870803532796.png)
3. echo&head&tail指令
![order_ech_head](vx_images/53334214658632.png)
![order_tail](vx_images/278094561559172.png)
4. 重定向指令  
![order_rediraction](vx_images/510895649761574.png)
5. ln指令  
![order_ln](vx_images/241936582366338.png)
6. history指令
![order_history](vx_images/331653913124764.png)

##### 时间指令  
![order_date](vx_images/329175996787394.png)
![set_date_cal_order](vx_images/376016551158219.png)

##### 查找指令
![order_find](vx_images/153566573758248.png)![order_locate](vx_images/10582091012520.png)
**补充：which 查找指令的位置。**
![order_grep](vx_images/547313953252797.png)

##### 压缩/解压指令
![order_gzip_gunzip](vx_images/527304530167610.png)
![order_zip_unzip](vx_images/420235846887005.png)
![order_tar](vx_images/361386117534512.png)

#### 组管理和权限管理
##### 组管理
![group_basic_intro](vx_images/419604052260562.png)
###### 所有者
```
# 查看文件的所有者
ls -ahl

#修改文件的所有者
chown username filename
```
###### 所在组
```
# 修改文件的所在组
chgrp groupname filename
```

###### 其他组
除文件的所有者和所在组的用户外，系统的其它用户都是文件的其它组。

###### 改变用户所在组
```
# 改变用户所在组
usermod -g groupname username

# 改变用户初始的登录目录 特别说明：需要有新目录的权限
usermod -d dirname username

```
##### 权限管理
###### 基本介绍
![permission_basic_intro](vx_images/237185982107053.png)
![permission_type](vx_images/355806070948755.png)
###### 修改权限指令chmod
![order_chmod](vx_images/261013460744205.png)
###### 所有者chown
![order_chown](vx_images/238772749646772.png)

#### 定时任务调度
##### crond
![order_crondtab](vx_images/557024020798239.png)
**补充：service crond restart[重启任务调度]**
![order_crondtab](vx_images/317963200672878.png)
![time_rule](vx_images/136723572636213.png)
![time_rule_example](vx_images/377314015954520.png)

##### at
![order_at](vx_images/426107106279793.png)
**补充：ctrl + D 输入两次**
![order_at](vx_images/588036890150302.png)
![order_at](vx_images/419736679047367.png)
![order_at](vx_images/68623683415453.png)

#### Linux磁盘分区/挂载
##### 原理介绍
![intro](vx_images/108643115299131.png)
![intro](vx_images/227394523088688.png)
```
# 查看所有设备挂载情况
lsblk or lsbolk -f
```

##### 实际操作
1. 虚拟机添加新的硬盘(重启后生效)  
直接通过虚拟软件添加
2. 分区  
对添加的硬盘进行分区sdb1-4
```
# n-增加分区 p-主分区
fdisk /dev/sdb 
```
3. 格式化  
```
mkfs -t [格式] [路径][例:/dev/sdb1]
```
4. 挂载  
```
# 挂载
mount [分区路径] [想要挂载的文件夹路径]
# 卸载
umount [分区路径]/[已挂载的文件夹路径]
```
5. 设置自动挂载  
命令行挂载重启后会失效，可以通过修改/etc/fstab文件自动挂载。
```
# 修改完成后生效指令
mount -a 
```
##### 查询指令

```
# 查询系统磁盘整体使用情况
df -h

# 查询指定目录的磁盘使用情况
du -h /dirname
```
![order_du](vx_images/883244500688.png)

##### 磁盘实用指令
```

# 统计目录下文件个数
ls -l /dirname | grep "^-" | wc -l

# 统计目录下文件个数，包括子目录下的
ls -lR /dirname | grep "^-" | wc -l

# 统计目录下目录个数
ls -l /dirname | grep "^d" | wc -l

# 统计目录下目录个数，包括子目录下的
ls -lR /dirname | grep "^d" | wc -l

# 树状显示目录  
tree /dirname

# 安装tree
yum install tree
```

#### 网络配置

##### 网络配置原理[网络链接的三种模式](#网络链接的三种模式)
![NAT_net_mode](vx_images/37067103752773.png)

相关指令
```
ifcofig # Linux、Mac
ipconfig # Windows
ping ipaddress # 测试网络联通性
```
##### 网络环境配置
1. 可以通过图形界面设置网络
2. 程序员方式  

```
# 编辑这个文件
vim /etc/sysconfig/network-scripts/ifcfg-ens33

# 更改如下地方
# 固定ip地址配置 BOOTPROTO=static/dhcp
＃IP地址
IPADDR=192.168.254.142
#网关
GATEWAY=192.168.254.0 

# 配置后生效
service network restart 
or
reboot
```
##### 设置主机名和hosts映射
1.设置主机名
```
# 重启后生效
vim /etc/hostname
```
2. 设置hosts映射  
```
vim /etc/hosts
例子：192.168.254.142 hostname
```
3. 主机名解析过程分析(Hosts、DNS)  
![hosts_DNS](vx_images/502262732698283.png)
**解析过程**
![ip_find_route](vx_images/158583177905569.png)

#### Linux进程管理
##### 查看进程指令
![order_ps](vx_images/76984100424887.png)
**notice: 一般使用 -aux 组合查看**<br>
![order_ps](vx_images/84365396055286.png)
##### 父子进程
```
-e 显示所有进程
-f 全格式
```
![order_ps_ef](vx_images/145454700548643.png)

##### 终止进程
```
kill [选项][-9] [进程号]
killall [进程名称]  # 终止进程与子进程 
```
##### 进程树
```
pstree [选项][-p -u]
```

#### Linux服务管理
##### 介绍
![servier_manager](vx_images/229133100661943.png)
![service_view](vx_images/319694535577072.png)
##### 运行级别与相关指令
![service_level](vx_images/345794654927326.png)
![order_checkconfig](vx_images/390935498890171.png)
![order_systemctl](vx_images/236116188822562.png)
##### 动态监控进程
###### 基本指令
```
top [options][-d -i -p]
```
###### 交互操作
![reaction](vx_images/423744957639551.png)
##### 监控网络状态 netstat
![order_netstat](vx_images/342235999960630.png)

#### Linux RPM与YUM
##### rpm包的管理
rpm 用于互联网下载包的打包及安装工具，它包含在某些 Linux 分发版中。它生成具有.RPM扩展名的文件。RPM是RedHat Package Manager (RedHat 软件包管理工具，的缩写，类似Windows的setup.exe，这一文件格式名称虽然打上了RedHat 的标志，但理念是通用的。
1. 查询
![rpm_qa](vx_images/442692168055198.png)
2. 卸载   
 ![rpm_delete](vx_images/74823047190184.png)
3. 安装  
![rpm_install](vx_images/275932655452921.png)  
  
##### yum包管理
Yum 是一个Shell前端软件包管理器。基于RPM包管理，能够从指定的服务器自动
下载RPM包井且安装，可以<mark>自动处理依赖性关系</mark>，井且一次安装所有依赖的软件包。
![order_yum](vx_images/531431868251116.png)

#### Java环境搭建 -- 需要时再研究

#### Shell编程
##### 执行方式
1. 授予可执行权限。
2. 用 “sh” 去执行文件。


##### 变量
![shell_var](vx_images/64375315294160.png)
![shell_var](vx_images/462795034311464.png)

##### 环境变量
![enviroment_path_set](vx_images/272425394015933.png)

##### 位置参数变量
![location_var](vx_images/116695279907846.png)

##### 预定义变量
![pre_var](vx_images/441675892820603.png)

##### 运算符
![operator_shell](vx_images/128182665940266.png)

##### 条件判断
![condition_shell](vx_images/476851102331461.png)
![condition_shell](vx_images/158962204912981.png)
##### 流程控制
![process_shell](vx_images/304436412996110.png)  
![process_shell](vx_images/163242153657576.png)

##### 循环语句
![for_shell](vx_images/73132657876473.png)
![while_shell](vx_images/66383810830183.png)

##### read语句
![read_shell](vx_images/501074053474650.png)

##### 函数
![fun_shell](vx_images/527966798445837.png)
![dirname](vx_images/195926647282042.png)
![fun_shell](vx_images/44782221106457.png)



----
----
----


```































```